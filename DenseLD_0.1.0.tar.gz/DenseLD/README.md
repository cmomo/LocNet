# Genetic Fine-mapping with Dense Linkage Disequilibrium Blocks (DenseLD)
This is a genetic fine-mapping method incorporating dense LD block structure of linkage disequilibrum (LD) matrix among SNPS from a genomic region of interest.

# Prerequisites
MATLAB is required for the analysis.
"denseLD.m" is a MATLAB function for dense block detection that originally from the "NICE.m" in a previous package https://github.com/shuochenstats/Network_program/tree/master/NICE_folder/NICE_detection. "denseLD.m" is a faster function than "NICE.m". 

"denseLD.m" can be downloaded at https://github.com/cmomo/DenseLD_Data/blob/main. 

Dense LD block detection can be performed either in MATLAB or called by R using function "dense_block" in the R package. 

## Dependency
DenseLD also requires R (>= 3.5.0) and R packages genlasso, graphics, R.matlab and matlabr for the analysis. Install these packages before the analysis. All sample data can be downloaded together from "data/data.zip".

# Installation
devtools::install_github('cmomo/DenseLD')

# Implementation
The implementation of DenseLD fine-mapping and sample data can be accessed at https://github.com/cmomo/DenseLD_Data. 





